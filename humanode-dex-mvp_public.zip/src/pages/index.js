// Swap UI home page
export default function Home() {
  return <div className='text-white'>Humanode DEX MVP</div>;
}