# Humanode DEX MVP

This is a minimal DEX interface for Humanode + Ethereum swap.
